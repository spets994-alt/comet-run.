# Comet Run Mobile

This project wraps the existing Comet Run HTML game as a native iPhone/iPad and Android app using Capacitor.

## Requirements
- Node.js
- For iPhone/iPad: macOS + Xcode
- For Android: Android Studio

## Build setup
```bash
npm install
npx cap add ios
npx cap add android
npx cap sync
```

## Open the native projects
```bash
npx cap open ios
npx cap open android
```

The existing game is in `www/index.html`.
