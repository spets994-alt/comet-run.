@echo off
npm install
npx cap add ios
npx cap add android
npx cap sync
echo.
echo Comet Run is ready. Use "npx cap open android" on Windows,
echo or use macOS + Xcode for the iOS project.
pause
